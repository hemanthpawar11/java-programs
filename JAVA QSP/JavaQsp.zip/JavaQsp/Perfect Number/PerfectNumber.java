import java.util.Scanner;

class PerfectNumber{
     public static void main (String[] args){
        Scanner sc = new Scanner (System.in);
       
        System.out.println("Enter a number:");
        int n = sc.nextInt();

       perfectNumber( n );

      

 
        
}
    public static void perfectNumber(int n)
      {
       int sum = 0; 
        for (int i=1; i<n ; i++)
           {
              if( n % i == 0)
                  { 
                    sum=sum+i;
                    }
           }
    if (sum==n)
             {
               System.out.println("Its is perfect number");
              }
         else
             {
               System.out.println("Not a perfect numebr");
             }
   }

         
}
        