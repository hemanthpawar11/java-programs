import java.util.Scanner;

class palindrome
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int n = sc.nextInt();
		int ori = n;
		int rev = 0;
		while(n!=0){
			
			int rem=n%10;
			rev=rev*10+rem;
			n=n/10;
			
		}
		if(ori==rev){
			System.out.println( ori + " is a palindrome");
		}
		else{
			System.out.println( ori + " is not a palindrome");
		}
			
	}
}
